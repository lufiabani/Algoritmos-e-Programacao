J = 60
I = 1

while J>0:
    print(f'I={I} J={J}')
    I += 3
    J -= 5