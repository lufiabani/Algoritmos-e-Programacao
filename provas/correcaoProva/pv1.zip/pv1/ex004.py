"""
A função retorna um valor ao progama.
"""