"""
Local e Global.

Local dentro de um escopo, global em todo o código
"""